export interface Studente {
    id: number;
    name: string;
}